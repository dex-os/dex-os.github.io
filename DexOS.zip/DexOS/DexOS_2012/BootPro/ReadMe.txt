Boot12.asm is the fasm ver of  Alexei A. Frounze, Great bootloader "bootprog",
See doc for info.
It as been changed to fasm from nasm, and one or two vars added.