Here is the latest ver of DexOS (v6), Your free to use its as you see fit,
but YOU MUST INCLUDE DexOS licence, if you use any code.
If you do not know what DexOS is,its a 32bit pm OS coded in full ASM.
It includes CLI, GUI, Fasm port and many more apps.
Theres also a full tcp/ip stack ver, available. 

Dex (a.k.a Craig Bamford).
