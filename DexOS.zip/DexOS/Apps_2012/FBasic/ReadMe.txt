This is a simple convertion of the "macro basic" done by rCX, more will be added.
