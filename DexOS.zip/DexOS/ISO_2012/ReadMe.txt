Use your CD burn software to burn to CD.
Dex.
