Copy floppy image to floppy, using winimage or use in a emulator.
Dex.
