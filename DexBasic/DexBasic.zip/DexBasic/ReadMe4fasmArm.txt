FASM-ARM v1.14

This package is an ARM assembler add-on for FASM.

There are a few restrictions how the ARM instruction set is implemented. The changes are minor and
mostly have a minor impact. For the most part the basic instruction outline is the same. Where possible
the original style is used but there are some differences:

1) all immediates are without hashes (FASM uses the hash for concatenation).
2) label names cannot begin with a digit.
3) CPSIE and CPSID formats are changed, use "iflags_aif" form instead of "aif" (eg. "CPSIE iflags_i"
   instead of "CPSID i").
4) SRS with writeback must have a separating comma after the mode number and before "!" (eg. use
   "SRSDB 16,!" instead of "SRSDB #16!").
5) macro, rept, irp, format, if, virtual etc. are all significant changes from the ARM ADS so you will
   need to re-write those sections of existing code.

	Original ARM Syntax   | Fasm ARM Syntax
	----------------------+----------------------
	mov r2,r3             | mov r2,r3
	add r5,r6,r7          | add r5,r6,r7
	sub r8,r4,r2,lsr #4   | sub r8,r4,r2,lsr 4
	eor r0,r5,#0xfffffffc | eor r0,r5,0xfffffffc
	ldr r1,[r5,#8]!       | ldr r1,[r5,8]!
	ldr r1,[r5],#8        | ldr r1,[r5],8
	cpsie a               | cpsie iflags_a
	srsdb #29!            | srsdb 29,!
	ldmia fp!,{r0-r3}     | ldmia fp!,{r0-r3}

The "format" directive will produce ARM code in all the same formats as the X86 version plus one
additional format: ELF DWARF. The ELF DWARF is compatible with the ARM AXD debugger. The DWARF format
produced includes all program labels, line numbers and module names for full symbolic debugging. The
ELF format has been changed to set the FLAGS, code base and machine type compatible for ARM-LINUX. The
PE format has been changed to set the machine type, subsystem and code base compatible with WinCE.

Use format like this to get the dwarf output:

	format elf dwarf executable [at ????????]

Line number and the symbol table generation are automatically enabled with this format. Using "at" is
optional and defaults to 0.

The "section" directive for DWARF output is like this:

	section "name" [executable | readable | writeable | at ????????] align ????????

The "name" is required. Align is required and must be a power of 2. All other
attributes are optional except that at least one of executable, readable or writeable must be
specified. Using "at" is optional and defaults to the next aligned address. Attributes can be specified
in any order except "name" which must be first.

The "org" directive is not allowed in DWARF output mode, otherwise everything is the same as for normal
ELF output.

Relocations for ELF and PE are not supported at this time. Although, one user has reported that
relocations are working correctly with PE format, use at your own risk, I have not tested them yet.

There are eight directives to control the code generation state:

	CODEV5   - Allows only ARMv5 (and lower versions) code generation
	CODEV6   - Allows ARMv5 (and lower versions) and ARMv6 code generation
	CODEVFP1 - Allows only VFPv1 code generation
	CODEVFP2 - Allows VFPv1 and VFPv2 code generation
	CODEFP   - Allows VFP code generation
	CODENOFP - Disallows VFP code generation
	CODE16   - Switches to THUMB (16bit instructions) code generation (alias USE16)
	CODE32   - Switches to ARM (32bit instructions) code generation (alias USE32)

At startup the default is CODEV5, CODEVFP1, CODENOFP, CODE32

There are four directives that are a combination of two code generation settings above:

	ARM5   - Combination of CODE32 and CODEV5
	ARM6   - Combination of CODE32 and CODEV6
	VFP1   - Combination of CODEFP and CODEVFP1
	VFP2   - Combination of CODEFP and CODEVFP2

Note: to select THUMB with ARMv6 enhancements you must use both CODEV6 and CODE16 in combination.

Data definitions are different between ARM and X86. A "word" in ARM is 32 bits.

	X86  ARM  comment
	---+----+---------
	DB | DB | same: 8 bits
	DW | DH | half word: 16 bits
	DU | DU | same: 16 bits
	DD | DW | word: 32 bits
	DQ | DD | double word: 64 bits
	RB | RB | same: 8 bits
	RW | RH | half word: 16 bits
	RD | RW | word: 32 bits
	RQ | RD | double word: 64 bits
	DF | -- |  not valid
	DP | -- |  not valid
	DT | -- |  not valid
	RF | -- |  not valid
	RP | -- |  not valid
	RT | -- |  not valid

Address sizes are always 32 bits in ARM and THUMB states, you can't use any address overrides.

Data sizes are different between ARM and X86. A "word" in ARM is 32 bits.

	 X86     ARM    comment
	------+-------+---------
	BYTE  | BYTE  | same: 8 bits
	WORD  | HWORD | half word: 16 bits
	DWORD | WORD  | word: 32 bits
	QWORD | DWORD | double word: 64 bits

You can still use all the pre-processor and assembly features of FASM including macros, structures,
repeats etc.

FASM-ARM supports the ARMv5TE (and lower) and ARMv6 instructions, VFPv1 and VFPv2 coprocessor, THUMB-1
and XScale additions for the 40 bit accumulator.

The five standard variants of FASM binaries can been produced for FASM-ARM:

	FASMARM.EXE  - WIN32 console
	FASMWARM.EXE - WIN32 IDE
	FASMARM      - LINUX
	FASMARM.O    - LIBC
	FASMDARM.EXE - DOS

If you have a problem, question, suggestion, comment etc. you can contact me at
http://board.flatassembler.net - my handle is revolution.

Visit http://www.arm.com for information on the ARM instruction sets and processors.
Visit http://flatassembler.net for the FASM x86 assembler package and tools.

If you want to recompile the FASMARM code you will need the flatassembler package from the above URL.

Version history:

v1.14 2010-Feb-01 - Updated for compatibility with FASM 1.69.11
                  - Changed "LDRx reg,[reg,0]!" to generate  "LDRx reg,[reg,0]"
                  - Changed "LDRx reg,[reg],0" to generate  "LDRx reg,[reg,0]"
                  - Changed "LDC Px,Cx,[reg,0]!" to generate  "LDC Px,Cx,[reg,0]"
                  - Changed "LDC Px,Cx,[reg],0" to generate  "LDC Px,Cx,[reg,0]"
                  - Fixed encoding for thumb mode BLX
                  - Fixed encoding for PKHTB without shift
                  - Fixed encoding for SSAT, SSAT16
                  - Fixed encoding for UMAAL
                  - Allowed rotation parameter for SXTB, SXTH, UXTB, UXTH

v1.13 2008-Nov-04 - Updated register restrictions for STREX, SMLALD, SMLSLD, UMAAL, SMLALxy
                  - Relaxed restriction of rotation count=0 (or omitted) for PKHTB
                  - Enabled THUMB mode aliases for SXTB, SXTH, UXTB, UXTH

v1.12 2008-Jul-13 - Updated for compatibility with FASM 1.67.27
                  - Fixed "error: undefined symbol" displaying the wrong line

v1.11 2008-Mar-20 - Updated for compatibility with FASM 1.67.26 (note: no version change)

v1.11 2007-Aug-31 - Updated for compatibility with FASM 1.67.22
                  - Fixed an address parser bug allowing "ldr rx,[constant]" without a register base

v1.10 2007-Mar-04 - Updated for compatibility with FASM 1.67.21 expression calculation
                  - Allowed forward referencing of register based structure addressing
                  - Fixed a bug in the ARMLITRL.INC when generating PC relative offsets

v1.09 2006-Aug-30 - Updated ARMTABLE.INC for compatibility with FASM 1.67 binary searches
                  - Updated PE format to initialise several accounting fields and also to reset
                     the "relocs stripped" flag if relocs are included

v1.08 2006-Jun-09 - Fixed erroneous error with implicit r0 based addressing
                  - Fixed priority of unary minus to match FASM v1.66 priority
                  - Relaxed restrictions with register structure addresses when using zero offset
                  - Enhanced MOV/MOVS to use ADD/SUB encoding when loading a register structure member
                  - Generation of special encoding to allow user code to detect unencodable immediates
                     and then select an alternate coding without causing assembly errors
                  - Alignment bytes changed to 0xff to facilitate faster FLASH ROM updates
                  - Added proc, apscall, import and literals macros to package,
                     see each individual file for usage and special notes
                  - STRUCT and RESOURCE converted from x86 to ARM format
                  - COREDLL.INC converted to an imports definition file

v1.07 2006-May-26 - Patch for basic "format PE" support for WinCE
                  - Added ARMPE example for WinCE (2006-06-02)
                  - COREDLL.DLL import ordinal equates added in "COREDLL.INC" (2006-06-02)

v1.06 2006-Mar-03 - Updated to work within FASM version 1.66

v1.05 2006-Feb-14 - Patch for basic "format ELF executable" support
                  - Added ARMELF example

v1.04 2005-Nov-09 - Fixed incorrect classification of data/code when using TIMES
                  - Improved line number embedding generation for more efficient tables

v1.03 2005-Oct-20 - Fixed IF/ELSE/END IF skip bug with commas

v1.02 2005-Oct-03 - Fixed CPS mode change code generation
                  - Fixed THUMB ASR and LSR shift range check

v1.01 2005-Oct-01 - Fixed STMIA THUMB instruction checking for base register validity
                  - Fixed error deferring for some expressions
                  - Fixed shift count of 32
                  - Added ARMv6 instructions
                  - Added VFPv2 instructions
                  - Added register aliases a1-a4, v1-v8, sb, sl, fp, ip
                  - Added CODE16, CODE32, CODEFP, CODENOFP, CODEV5, CODEV6, CODEVFP1, CODEVFP2 directives
                  - Added ARM5, ARM6, VFP1, VFP2  combination directives
                  - Enforced code typing (generates an error if new instructions are used but not enabled)
                  - Enforced VFP to be explicitly enabled before use
                  - Removed condition code "NV"

v1    2005-Sep-29 - First public release

(C) 01-February-2010 revolution
