\\|//
(@ @)
Dex4u

Hi, fallow OS hackers, A quick note about MiniDOS, in the zip you will find "MiniDOS.exe", this
will put the OS (MiniDOS) on to a floppy, along with some test programs
They are code with fasm, tasm, turbo pascal, turbo-C etc.
Just click on the exe and follow the instrutions and than reboot. Also in the zip
you will find full commented fasm source code, to MiniDOS, Along with source code to
the modded bootloader.
Basically it a small dos that can run some old dos programs, as it includes some int 21h
functions, the idea is that everyone adds just one int 21h function, it will build into 
a good free open fasm dos.
Also its written as a basic tut for beginner OS Dev's, As it got all the basics in a small
package, including Command line interface, Dir, loads, runs com and exe in less than 2K.

So what are you waitingfor, get coding ;).

Regards Dex (Craig Bamford).

 